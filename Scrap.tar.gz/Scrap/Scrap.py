
from urllib.request import urlopen
import requests
from bs4 import BeautifulSoup
import csv
from csv import reader
import os
import time

class Scrap():
    
    def __init__(self):
        self.URL_TRT  = "https://bibliotecadigital.trt1.jus.br"
        self.URL_PESQ = "https://bibliotecadigital.trt1.jus.br/jspui/handle/1001/685849/simple-search?query=a%C3%A7%C3%A3o+civil+p%C3%BAblica"
        self.new_page = 'https://bibliotecadigital.trt1.jus.br/jspui/handle/1001/685849/simple-search?query=a%C3%A7%C3%A3o+civil+p%C3%BAblica&sort_by=score&order=desc&location=1001/685849&rpp=10&etal=0&start='
        self.arq_links_pdfs = 'links_pdfs_TRT1.csv'
        self.FOLDER_BASE = "/home/info/MyNotebooks/Datasets/SentencasTRT1/"
        self.list_links = list()
        self.start_page = 16010
        self.end_page = 16020
        self.idx = 0
        
    
    def setUrlPesq(self, URL):
        self.URL_PESQ = URL
        
    def setDsFolder(self, URL):
        self.DS_FOLDER = URL
        
    def criaListaLinks(self):
        html = urlopen(self.URL_PESQ)
        bsObj = BeautifulSoup(html.read())

        # obtem uma lista contendo todos os processos referenciados na pagina atual
        list_processos = bsObj.findAll('a', href=True, attrs={'style': 'font-size: large;'})
        
        for i in list_processos:
            nr_processo = i.contents[0]
            # print(nr_processo)
            pagina_processo = self.URL_TRT + i.get('href')
            # print(pagina_processo)
            html_processo = urlopen(pagina_processo)
            bs_processo = BeautifulSoup(html_processo.read())
            link_pdf = self.URL_TRT + bs_processo.find('a', href=True, attrs={'target': '_blank'})['href']
            self.list_links.append(link_pdf)
            
        
          
    def downloadListaPDFs(self, inicio, fim):
        self.start_page = int(str(inicio))
        self.end_page   = int(str(fim))
        
        self.idx = 0
        
        # considerando que temos 10 links de pdfs por pagina o passo sera 10 (em cada pagina 10 links sao extraídos)
        for k in range(self.start_page, self.end_page, 10):
          self.setUrlPesq(self.new_page+str(k))
          self.criaListaLinks()
          self.idx = k      
        
        self.arq_links_pdfs = 'links_pdfs_TRT1-from-'+str(self.start_page)+'-to-'+str(self.end_page)+'-idx='+str(self.idx)+'.csv'
        return(self.arq_links_pdfs)

            
    def saveCSV(self):
        
        #if not os.path.isdir(self.FOLDER_BASE):
        #    os.makedirs(self.FOLDER_BASE)

        # 1. abrir o arquivo e grava os links para download num .csv
        
        print(len(self.list_links))
        for i in range(len(self.list_links)):
            print(self.list_links[i])
        
        
        with open('{file_path}'.format(file_path=os.path.join(self.FOLDER_BASE, self.arq_links_pdfs)), 'w', newline='', encoding='utf-8') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerows(([str(row)] for row in self.list_links))
        csv_file.close()

        
    def downloadPDFs(self, file):
        arquivo = self.FOLDER_BASE+file
        lista_links = list()
        
        # Abre o arquivo.csv contendo os links diretos dos PDFs.
        with open(arquivo, "r", newline="", encoding="utf-8") as f:
            csv_reader = reader(f)

            # Iterate over each row in the csv using reader object
            for row in csv_reader:
                # row variable is a list that represents a row in csv
                lista_links.append(row)
                # self.list_links.append(f.read().split(','))
            
        f.close()         
        print(len(lista_links))
        
        for i in range(len(lista_links)):
            lista_links[i] = str(lista_links[i]).replace("\n", "")
            lista_links[i] = str(lista_links[i]).replace("\r", "")
            lista_links[i] = str(lista_links[i]).replace("\"", "")
            lista_links[i] = str(lista_links[i]).replace("[\'", "")
            lista_links[i] = str(lista_links[i]).replace("\']", "")
            
        
        
        #Faz o download de cada item da lista (link direto do pdf) e grava em um arquivo pdf na pasta.
        for i in range(len(lista_links)):
            print(type(lista_links))
            pdf = str(lista_links[i])
            print(pdf)
            print(type(pdf))
            response = requests.get(pdf)
            processo = lista_links[i].split("/")[-1]
            arq_dest = self.FOLDER_BASE+"/PDFs/"+processo
            with open(arq_dest, 'wb') as f:
                f.write(response.content)
            f.close()

                 
