# Download automatico das Sentenças (Scrap) em pdf
print("Scrap module")
