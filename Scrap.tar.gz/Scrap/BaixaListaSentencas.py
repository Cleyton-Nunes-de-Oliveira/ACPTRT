#
# Cria uma lista com os links dos pdfs de processos listados na pagina de busca e salva em .csv
# Ver Colab: ScrapySentencasTRT1.ipynb
#

from urllib.request import urlopen
from bs4 import BeautifulSoup

URL_PESQ = "https://bibliotecadigital.trt1.jus.br/jspui/handle/1001/685849/simple-search?query=a%C3%A7%C3%A3o+civil+p%C3%BAblica"
URL_TRT = 'https://bibliotecadigital.trt1.jus.br'

list_links = list()

def process_page_pesq(URL_PESQ):
  html = urlopen(URL_PESQ)
  bsObj = BeautifulSoup(html.read())

  # obtem uma lista contendo todos os processos referenciados na pagina atual
  list_processos = bsObj.findAll('a', href=True, attrs={'style': 'font-size: large;'})

  for i in list_processos:
    nr_processo = i.contents[0]
    # print(nr_processo)
    pagina_processo = URL_TRT + i.get('href')
    # print(pagina_processo)
    html_processo = urlopen(pagina_processo)
    bs_processo = BeautifulSoup(html_processo.read())
    link_pdf = URL_TRT + bs_processo.find('a', href=True, attrs={'target': '_blank'})['href']
    list_links.append(link_pdf)
